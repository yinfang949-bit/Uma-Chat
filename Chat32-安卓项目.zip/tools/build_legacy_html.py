#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""把 chat32-ui/index.html（现代版）转换为 Android 4.x 老版 WebView 兼容版：
1. CSS 变量 var(--x) 全部替换为字面量（老内核不支持 CSS 变量）
2. inset / min() 等新语法加回退
3. 注入 -webkit-box 老式弹性布局回退（关键容器）
4. JS 用 Babel 转 ES5（箭头函数/模板字符串/let/const）
5. 补 polyfill（startsWith / padStart / Object.entries）
输出：chat32-android/app/src/main/assets/index.html（打进 APK 的版本）
现代浏览器（Android 5.0+ WebView）行为不变。
"""
import re, subprocess, base64, os

SRC = '/home/user/Doubao/chats/38443985569965058/chat32-ui/index.html'
OUT = '/home/user/Doubao/chats/38443985569965058/chat32-android/app/src/main/assets/index.html'
BABEL_DIR = '/tmp/babel'

s = open(SRC, encoding='utf-8').read()

# ---- 1. CSS 变量 -> 字面量 ----
m = re.search(r':root\s*\{(.*?)\}', s, re.S)
vars_map = {}
for k, v in re.findall(r'(--[\w-]+)\s*:\s*([^;]+);', m.group(1)):
    vars_map[k] = v.strip()
def repl_var(mo):
    return vars_map.get(mo.group(1), mo.group(0))
s = re.sub(r'var\((--[\w-]+)\)', repl_var, s)

# ---- 2. 新语法回退 ----
s = s.replace('inset:0;', 'top:0;right:0;bottom:0;left:0;inset:0;')
s = s.replace('max-width:min(72%, 620px);', 'max-width:72%; max-width:min(72%, 620px);')

# ---- 3. -webkit-box 兼容块（必须在 :root 之后、现代规则之前注入） ----
compat = '''
  /* ===== Android 4.x 老版 WebView 兼容：-webkit-box 回退（现代浏览器忽略） ===== */
  #login-view { display:-webkit-box; -webkit-box-pack:center; -webkit-box-align:center; }
  .brand { display:-webkit-box; -webkit-box-align:center; }
  .login-actions { display:-webkit-box; }
  .login-tip { display:-webkit-box; -webkit-box-align:start; }
  #chat-view { display:-webkit-box; -webkit-box-orient:vertical; }
  #room-title { display:-webkit-box; -webkit-box-align:center; }
  #back-btn { display:-webkit-box; -webkit-box-pack:center; -webkit-box-align:center; }
  #main { display:-webkit-box; -webkit-box-orient:vertical; -webkit-box-flex:1; }
  #messages { -webkit-box-flex:1; }
  .msg { display:-webkit-box; }
  .msg.mine { -webkit-box-direction:reverse; }
  .msg-body { display:-webkit-box; -webkit-box-orient:vertical; }
  .msg.mine .msg-body { -webkit-box-align:end; }
  .meta { display:-webkit-box; }
  .avatar { display:-webkit-box; -webkit-box-pack:center; -webkit-box-align:center; }
  #priv-list { -webkit-box-flex:1; }
  .priv-row { display:-webkit-box; -webkit-box-align:center; }
  .priv-row .uname { -webkit-box-flex:1; }
  .badge { display:-webkit-box; -webkit-box-pack:center; -webkit-box-align:center; }
  #settings { -webkit-box-flex:1; }
  #settings h3 { display:-webkit-box; -webkit-box-align:center; }
  .seg { display:-webkit-box; }
  .seg-btn { -webkit-box-flex:1; }
  #tabbar { display:-webkit-box; }
  .tab { display:-webkit-box; -webkit-box-orient:vertical; -webkit-box-flex:1; -webkit-box-pack:center; -webkit-box-align:center; }
  #input-row { display:-webkit-box; -webkit-box-pack:end; -webkit-box-align:end; }
  #input { -webkit-box-flex:1; }
  #send { display:-webkit-box; -webkit-box-pack:center; -webkit-box-align:center; }
  #egg { display:-webkit-box; -webkit-box-pack:center; -webkit-box-align:center; }
  .egg-marquee { display:-webkit-box; -webkit-box-pack:center; -webkit-box-align:center; }
'''
pos = m.end()
s = s[:pos] + compat + s[pos:]

# ---- 4. 提取并转换 JS ----
ms = re.search(r'<script>(.*?)</script>', s, re.S)
assert ms, '未找到 <script> 块'
js = ms.group(1)

node_src = '''
const babel = require('@babel/standalone');
let src = Buffer.from(process.argv[1], 'base64').toString('utf8');
const out = babel.transform(src, {
  presets: [['env', { modules: false, targets: { chrome: '18' } }]],
  comments: false,
});
process.stdout.write(out.code);
'''
res = subprocess.run(['node', '-e', node_src, base64.b64encode(js.encode('utf-8')).decode()],
                     capture_output=True, cwd=BABEL_DIR)
if res.returncode != 0:
    raise SystemExit('Babel 失败: ' + res.stderr.decode()[:500])
es5 = res.stdout.decode('utf-8')

# ---- 5. polyfill ----
poly = '''/* ES6+ 方法兼容（Android 4.x 老 WebView） */
if (!String.prototype.startsWith) { String.prototype.startsWith = function(prefix) { return this.indexOf(prefix) === 0; }; }
if (!String.prototype.padStart) { String.prototype.padStart = function(len, ch) { ch = ch === undefined ? ' ' : String(ch); var t = String(this); while (t.length < len) { t = ch + t; } return t; }; }
if (!Object.entries) { Object.entries = function(obj) { var k, r = []; for (k in obj) { if (Object.prototype.hasOwnProperty.call(obj, k)) { r.push([k, obj[k]]); } } return r; }; }
'''

# ---- 6. 组装输出 ----
s = s[:ms.start()] + '<script>\n' + poly + '\n' + es5 + '\n</script>' + s[ms.end():]
open(OUT, 'w', encoding='utf-8').write(s)
print('输出:', OUT, os.path.getsize(OUT), 'bytes')
