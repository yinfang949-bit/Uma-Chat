# Chat32 安卓客户端

极简纯文字聊天软件 Chat32 的安卓版：一个系统 WebView 直接加载打包在 `assets/index.html` 里的聊天界面，
页面通过 `WebSocket(ws:// 或 wss://)` 连接你自己的聊天服务器（`server.js`，可在 Termux 里跑）。

- **包名**：`com.chat32.app`
- **语言**：Java（原生 `Activity`，零第三方依赖，不依赖 androidx）
- **最低版本**：Android 4.0.3（API 15），向上兼容；32 位 / 64 位手机均可安装
- **APK 大小**：约 30 KB

## 功能一览

- 账号 = 名称 + 服务器密码（与 server.js 的 `CHAT_PASSWORD` 一致），本地记录登录信息
- 公共群聊 + 私聊（在线用户自动出现在私聊列表，未读角标）
- 只发文字，不支持图片/视频/GIF
- 黑底、白色默认头像、柔和青色主题；底部三栏导航：聊天 / 私聊 / 设置
- 聊天记录存本机 localStorage，服务器补发最近消息
- 设置页：服务器地址、名称/密码、主题颜色、气泡字号、清除本地记录、退出登录
- 彩蛋：设置页最底部"~ still in love ~"连点 3 次

## 目录结构

```
chat32-android/
├── app/src/main/
│   ├── AndroidManifest.xml          # 权限（INTERNET + 明文 ws 放行）
│   ├── assets/index.html           # 打进 APK 的聊天界面（老 WebView 兼容版）
│   ├── java/com/chat32/app/MainActivity.java
│   └── res/                        # 主题 + 各密度启动图标
├── tools/build_legacy_html.py      # 把现代版 index.html 转成兼容版（见下）
├── build_apk.sh                    # 无需 Android Studio 的一键构建脚本
└── Chat32-debug.apk                # 已签名可安装包
```

## 关于网页的两个版本

- **网页版** `chat32-ui/index.html`：现代浏览器专用（Android 5.0+ 的 WebView 也算现代）。
- **App 内置版** `assets/index.html`：由 `tools/build_legacy_html.py` 自动生成，
  做了老 WebView 兼容：CSS 变量替换成字面量、JS 用 Babel 转 ES5、
  补 startsWith/padStart/Object.entries polyfill、关键布局加 `-webkit-box` 回退。
  现代浏览器跑起来行为不变。

改完网页版后，重新生成并打包：

```bash
python3 tools/build_legacy_html.py
SDK=/path/to/android-sdk ./build_apk.sh
```

## 如何用 Android Studio 构建

1. `Open` 打开本目录（`settings.gradle` / `build.gradle` 已配好，AGP 8.2.2）。
2. `Build -> Build Bundle(s)/APK(s) -> Build APK(s)`，产物在 `app/build/outputs/apk/debug/`。

## 安装后怎么连服务器（重要）

朋友安装 APK 后，打开 App，在 **设置 -> 服务器地址** 里填：

- 同一 WiFi：你手机的局域网 IP，如 `ws://192.168.1.15:8080`
- 不同网络：内网穿透地址，如 `wss://xxxx.lhr.life`

App 已允许明文 `ws://`（manifest 里 `usesCleartextTraffic="true"`）。
服务器端 `server.js` 和 Termux 不用改，继续照常运行。

## 与网上教程的差异（为什么这样做）

| 教程 | 本实现 |
| --- | --- |
| `AppCompatActivity`（依赖 androidx appcompat） | 原生 `Activity`，零依赖，APK 更小、4.0.3 更稳 |
| minSdk 21 | minSdk 15（安卓 4.0.3，按你的要求） |
| 网页直接用 | 内置版做了老 WebView 兼容转换 |
| 32 位靠 abiFilters | 无原生代码，天然兼容 armeabi-v7a 32 位（gradle 里仍保留 abiFilters） |
