#!/usr/bin/env bash
# Chat32 安卓客户端一键构建脚本（无需 Android Studio / Gradle）
# 依赖：JDK 8+、Android build-tools(34) 与 platform android-34 的 android.jar
# 用法：SDK=/path/to/sdk ./build_apk.sh
#   SDK 目录下需有 android-14/{aapt2,d8,zipalign,apksigner} 与 android-34/android.jar
set -euo pipefail
cd "$(dirname "$0")"

SDK="${SDK:-/tmp/android-sdk}"
BT="$SDK/android-14"
PLAT="$SDK/android-34/android.jar"

echo "== 1/6 编译 Java（javac）=="
rm -rf build/classes && mkdir -p build/classes
javac -source 8 -target 8 -encoding UTF-8 \
  -bootclasspath "$PLAT" \
  -d build/classes \
  app/src/main/java/com/chat32/app/MainActivity.java

echo "== 2/6 编译资源（aapt2 compile）=="
rm -rf build/res build/res.zip && mkdir -p build/res
"$BT/aapt2" compile --dir app/src/main/res -o build/res.zip

echo "== 3/6 链接资源并打包（aapt2 link，含 assets）=="
rm -f build/base.apk
"$BT/aapt2" link -o build/base.apk \
  -I "$PLAT" \
  --manifest app/src/main/AndroidManifest.xml \
  -A app/src/main/assets \
  --min-sdk-version 15 \
  --target-sdk-version 34 \
  --version-code 1 \
  --version-name 1.0 \
  build/res.zip

echo "== 4/6 转 dex（d8）=="
rm -rf build/dex && mkdir -p build/dex
"$BT/d8" --release --lib "$PLAT" --min-api 15 \
  --output build/dex \
  build/classes/com/chat32/app/*.class

echo "== 5/6 装入 classes.dex 并对齐 =="
python3 - <<'PY'
import zipfile
apk = 'build/base.apk'
out = 'build/with_dex.apk'
zin = zipfile.ZipFile(apk, 'r')
zout = zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED)
for item in zin.infolist():
    zout.writestr(item, zin.read(item.filename))
zout.write('build/dex/classes.dex', 'classes.dex')
zout.close(); zin.close()
PY
rm -f build/aligned.apk
"$BT/zipalign" -f 4 build/with_dex.apk build/aligned.apk

echo "== 6/6 签名（debug key）=="
if [ ! -f build/debug.keystore ]; then
  keytool -genkeypair -keystore build/debug.keystore \
    -alias androiddebugkey -storepass android -keypass android \
    -keyalg RSA -keysize 2048 -validity 10000 \
    -dname "CN=Android Debug,O=Android,C=US"
fi
"$BT/apksigner" sign \
  --ks build/debug.keystore --ks-pass pass:android --key-pass pass:android \
  --out Chat32-debug.apk build/aligned.apk

echo "== 完成 =="
"$BT/apksigner" verify --verbose Chat32-debug.apk | head -4
"$BT/aapt2" dump badging Chat32-debug.apk | grep -E "^package|sdkVersion|application-label:" | head -6
ls -la Chat32-debug.apk
