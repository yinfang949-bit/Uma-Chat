package com.chat32.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

/**
 * Chat32 安卓客户端。
 * 用系统 WebView 直接加载 assets/index.html（本地网页，不联网下载页面），
 * 页面内通过 WebSocket(ws:// 或 wss://) 连接你自己的聊天服务器。
 * 兼容 Android 4.0.3 (API 15) 及以上，32/64 位均可安装。
 */
public class MainActivity extends Activity {
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 直接用 WebView 作为整个界面
        webView = new WebView(this);
        setContentView(webView);

        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);      // 必须开，登录/发消息全靠 JS
        ws.setDomStorageEnabled(true);      // 允许 localStorage 保存聊天记录
        ws.setAllowFileAccess(true);        // 允许读取本地文件（assets）
        ws.setAllowContentAccess(true);

        // 页面内跳转都在本 App 内打开，不跳到系统浏览器
        webView.setWebViewClient(new WebViewClient());

        // 加载打包进 assets 的聊天界面
        webView.loadUrl("file:///android_asset/index.html");
    }

    // 返回键：网页能回退就回退，不能才退出 App
    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
