package com.chat32.server;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/**
 * Chat32 服务器 App 主界面：
 * 一键启动 Chat32 聊天服务器（内嵌 Node.js）+ cloudflared 内网穿透，
 * 显示公网地址并支持一键复制。
 */
public class MainActivity extends Activity {

    private TextView statusText;
    private TextView urlText;
    private TextView detailText;
    private Button mainBtn;
    private Button copyBtn;
    private final Handler handler = new Handler();

    private final ServerService.Listener serviceListener = new ServerService.Listener() {
        @Override
        public void onStateChanged(final boolean running, final String url, final String detail) {
            handler.post(new Runnable() {
                @Override
                public void run() {
                    updateUi(running, url, detail);
                }
            });
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
        ServerService.setListener(serviceListener);
        refreshFromService();
    }

    @Override
    protected void onResume() {
        super.onResume();
        ServerService.setListener(serviceListener);
        refreshFromService();
    }

    @Override
    protected void onDestroy() {
        ServerService.setListener(null);
        super.onDestroy();
    }

    private void refreshFromService() {
        updateUi(ServerService.isRunning(), ServerService.getPublicUrl(), "");
    }

    private void updateUi(boolean running, String url, String detail) {
        if (statusText == null) return;
        if (running) {
            statusText.setText("服务器运行中");
            statusText.setTextColor(0xFF4ADE80);
            mainBtn.setText("停止服务器（退出 App）");
            copyBtn.setVisibility(View.VISIBLE);
            if (url != null && !url.isEmpty()) {
                urlText.setText(url);
                detailText.setText("公网地址：朋友在客户端“服务器地址”里填这个即可连接\n（同一 WiFi 也可直接填本机局域网 IP:8080）");
            } else {
                urlText.setText("正在获取穿透地址…");
                if (detail != null && !detail.isEmpty()) detailText.setText(detail);
                else detailText.setText("内网穿透连接中，约需 10~30 秒…");
            }
        } else {
            statusText.setText("服务器已停止");
            statusText.setTextColor(0xFFFF6B6B);
            mainBtn.setText("启动服务器");
            copyBtn.setVisibility(View.GONE);
            urlText.setText("—");
            detailText.setText(detail == null || detail.isEmpty() ? "点击“启动服务器”开始" : detail);
        }
    }

    private void buildUi() {
        int bg = 0xFF0D1B23;
        int surface = 0xFF14262F;
        int text = 0xFFD6EDF0;
        int muted = 0xFF8FB3BC;
        int accent = 0xFF2BB8C9;

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bg);
        root.setPadding(dp(24), dp(40), dp(24), dp(24));

        TextView title = new TextView(this);
        title.setText("Chat32 服务器");
        title.setTextColor(text);
        title.setTextSize(24);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        TextView sub = new TextView(this);
        sub.setText("一键启动聊天服务器 + 内网穿透");
        sub.setTextColor(muted);
        sub.setTextSize(13);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, dp(6), 0, dp(24));
        root.addView(sub);

        // 状态卡片
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackgroundColor(surface);
        card.setPadding(dp(20), dp(18), dp(20), dp(18));
        LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        root.addView(card, cardLp);

        statusText = new TextView(this);
        statusText.setText("服务器已停止");
        statusText.setTextColor(0xFFFF6B6B);
        statusText.setTextSize(17);
        statusText.setTypeface(Typeface.DEFAULT_BOLD);
        card.addView(statusText);

        urlText = new TextView(this);
        urlText.setText("—");
        urlText.setTextColor(accent);
        urlText.setTextSize(15);
        urlText.setPadding(0, dp(10), 0, 0);
        urlText.setTypeface(Typeface.MONOSPACE);
        card.addView(urlText);

        detailText = new TextView(this);
        detailText.setText("点击“启动服务器”开始");
        detailText.setTextColor(muted);
        detailText.setTextSize(12);
        detailText.setPadding(0, dp(8), 0, 0);
        detailText.setLineSpacing(0, 1.4f);
        card.addView(detailText);

        // 复制按钮
        copyBtn = new Button(this);
        copyBtn.setText("复制公网地址");
        copyBtn.setVisibility(View.GONE);
        copyBtn.setAllCaps(false);
        copyBtn.setTextColor(text);
        copyBtn.setTextSize(14);
        copyBtn.setBackgroundColor(0xFF1B333E);
        LinearLayout.LayoutParams copyLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        copyLp.topMargin = dp(12);
        copyBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = urlText.getText().toString();
                if (url == null || url.isEmpty() || url.equals("—")) return;
                ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                cm.setPrimaryClip(ClipData.newPlainText("chat32", url));
                copyBtn.setText("已复制");
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() { copyBtn.setText("复制公网地址"); }
                }, 1500);
            }
        });
        root.addView(copyBtn, copyLp);

        // 主按钮
        mainBtn = new Button(this);
        mainBtn.setText("启动服务器");
        mainBtn.setAllCaps(false);
        mainBtn.setTextColor(Color.WHITE);
        mainBtn.setTextSize(17);
        mainBtn.setTypeface(Typeface.DEFAULT_BOLD);
        mainBtn.setBackgroundColor(0xFF2BB8C9);
        LinearLayout.LayoutParams mainLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(52));
        mainLp.topMargin = dp(16);
        mainBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ServerService.isRunning()) {
                    // 停止：停服务并退出进程（内嵌 Node 只能随进程退出）
                    stopService(new Intent(MainActivity.this, ServerService.class));
                    android.os.Process.killProcess(android.os.Process.myPid());
                } else {
                    startServerService();
                }
            }
        });
        root.addView(mainBtn, mainLp);

        // 电池优化
        Button batteryBtn = new Button(this);
        batteryBtn.setText("关闭电池优化（防杀后台）");
        batteryBtn.setAllCaps(false);
        batteryBtn.setTextColor(text);
        batteryBtn.setTextSize(13);
        batteryBtn.setBackgroundColor(0xFF1B333E);
        LinearLayout.LayoutParams batLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        batLp.topMargin = dp(12);
        batteryBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    if (Build.VERSION.SDK_INT >= 23) {
                        Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                                Uri.parse("package:" + getPackageName()));
                        startActivity(i);
                    }
                } catch (Exception ignored) {
                }
            }
        });
        root.addView(batteryBtn, batLp);

        // 说明
        TextView hint = new TextView(this);
        hint.setText("· 服务器端口 8080，密码默认 chat32\n"
                + "· 开机自启：部分系统需在“自启动管理”里手动允许本 App\n"
                + "· 停止服务器会退出 App（内嵌 Node 无法单独停）\n"
                + "· 本机访问 http://127.0.0.1:8080 可查看服务状态");
        hint.setTextColor(muted);
        hint.setTextSize(12);
        hint.setLineSpacing(0, 1.5f);
        hint.setPadding(0, dp(16), 0, 0);
        root.addView(hint);

        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        setContentView(sv);
    }

    private void startServerService() {
        Intent i = new Intent(this, ServerService.class);
        if (Build.VERSION.SDK_INT >= 26) {
            startForegroundService(i);
        } else {
            startService(i);
        }
        updateUi(true, "", "正在启动…");
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
