package com.chat32.server;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import android.util.Log;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Chat32 服务器前台服务：
 * 1) 用内嵌 Node.js（libnode.so）跑 server.js
 * 2) 启动 cloudflared 内网穿透并抓取公网地址
 * 3) 前台通知常驻 + 唤醒锁保活；开机自启由 BootReceiver 触发
 */
public class ServerService extends Service {

    public interface Listener {
        void onStateChanged(boolean running, String url, String detail);
    }

    private static Listener listener;
    public static void setListener(Listener l) { listener = l; }

    private static final String CHANNEL_ID = "chat32_server";
    private static final int NOTIF_ID = 1;

    private static boolean running = false;
    private static String publicUrl = "";

    private Thread nodeThread;
    private Process tunnelProcess;
    private Thread tunnelReader;
    private PowerManager.WakeLock wakeLock;

    public static boolean isRunning() { return running; }
    public static String getPublicUrl() { return publicUrl; }

    // JNI：启动 Node 运行时（native-lib.so 实现）
    public native int startNodeWithArguments(String[] arguments);

    @Override
    public void onCreate() {
        super.onCreate();
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "chat32:server");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startForeground(NOTIF_ID, buildNotification("正在启动…", ""));
        if (!running) {
            running = true;
            try {
                if (wakeLock != null && !wakeLock.isHeld()) wakeLock.acquire();
            } catch (Exception ignored) {}
            startNode();
            startTunnel();
        }
        return START_STICKY;
    }

    // ---------- Node.js 服务器 ----------
    private void startNode() {
        nodeThread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    File dir = new File(getFilesDir(), "nodejs-project");
                    if (!dir.exists()) dir.mkdirs();
                    copyAsset("main.js", new File(dir, "main.js"));
                    copyAsset("server.js", new File(dir, "server.js"));
                    System.loadLibrary("node");
                    System.loadLibrary("native-lib");
                    setState(true, "", "Node.js 已启动");
                    startNodeWithArguments(new String[]{"node", new File(dir, "main.js").getAbsolutePath()});
                    // node 正常退出（理论上不会）
                    setState(false, publicUrl, "Node.js 已退出");
                } catch (final Throwable t) {
                    running = false;
                    setState(false, "", "Node 启动失败：" + t.getMessage());
                }
            }
        }, "chat32-node");
        nodeThread.start();
    }

    // ---------- cloudflared 内网穿透 ----------
    private void startTunnel() {
        try {
            File bin = new File(getFilesDir(), "cloudflared");
            copyAsset("cloudflared", bin);
            if (bin.exists()) bin.setExecutable(true, true);

            ProcessBuilder pb = new ProcessBuilder(bin.getAbsolutePath(),
                    "tunnel", "--url", "http://127.0.0.1:8080", "--no-autoupdate");
            pb.environment().put("HOME", getFilesDir().getAbsolutePath());
            pb.redirectErrorStream(true);
            tunnelProcess = pb.start();

            tunnelReader = new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        BufferedReader r = new BufferedReader(new InputStreamReader(tunnelProcess.getInputStream()));
                        PrintWriter log = new PrintWriter(new FileWriter(new File(getFilesDir(), "cloudflared.log"), true));
                        String line;
                        Pattern urlPat = Pattern.compile("https://[a-z0-9-]+\\.trycloudflare\\.com");
                        while ((line = r.readLine()) != null) {
                            log.println(line);
                            log.flush();
                            Matcher m = urlPat.matcher(line);
                            if (m.find() && publicUrl.isEmpty()) {
                                publicUrl = m.group(0);
                                setState(true, publicUrl, "穿透成功");
                            }
                        }
                        log.close();
                    } catch (Exception ignored) {}
                }
            }, "chat32-tunnel");
            tunnelReader.start();

            // 90 秒还没拿到地址就提示（多半是网络/DNS 问题）
            Thread timeoutCheck = new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Thread.sleep(90000);
                    } catch (InterruptedException e) {
                        return;
                    }
                    if (running && publicUrl.isEmpty()) {
                        setState(true, "", "穿透地址获取超时：请检查网络或重启；日志见 cloudflared.log");
                    }
                }
            }, "chat32-timeout");
            timeoutCheck.start();
        } catch (final IOException e) {
            setState(running, publicUrl, "cloudflared 启动失败：" + e.getMessage());
        }
    }

    private void setState(final boolean run, final String url, final String detail) {
        running = run;
        publicUrl = url;
        if (listener != null) {
            try { listener.onStateChanged(run, url, detail); } catch (Exception ignored) {}
        }
        try {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            nm.notify(NOTIF_ID, buildNotification(run ? "服务器运行中" : "服务器已停止",
                    url == null || url.isEmpty() ? detail : url));
        } catch (Exception ignored) {}
    }

    private Notification buildNotification(String title, String text) {
        Intent i = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, i,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "Chat32 服务器",
                    NotificationManager.IMPORTANCE_LOW);
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            nm.createNotificationChannel(ch);
            b = new Notification.Builder(this, CHANNEL_ID);
        } else {
            b = new Notification.Builder(this);
        }
        b.setContentTitle(title)
                .setContentText(text == null ? "" : text)
                .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
                .setContentIntent(pi)
                .setOngoing(true);
        return b.build();
    }

    @Override
    public void onDestroy() {
        if (tunnelProcess != null) {
            try { tunnelProcess.destroy(); } catch (Exception ignored) {}
            tunnelProcess = null;
        }
        if (wakeLock != null && wakeLock.isHeld()) {
            try { wakeLock.release(); } catch (Exception ignored) {}
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    private void copyAsset(String name, File out) throws IOException {
        InputStream in = getAssets().open(name);
        FileOutputStream fos = new FileOutputStream(out);
        byte[] buf = new byte[65536];
        int n;
        while ((n = in.read(buf)) > 0) fos.write(buf, 0, n);
        fos.close();
        in.close();
    }
}
