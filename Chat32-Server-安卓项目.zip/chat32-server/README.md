# Chat32 服务器 App（一键启动：Node.js + cloudflared 内网穿透）

把 **Node.js 运行时（nodejs-mobile 的 libnode.so）+ chat32 的 server.js + cloudflared 二进制** 全部塞进一个安卓 App。
打开 App 点一下"启动服务器"，它自动：
1. 在前台服务里用内嵌 Node 跑 Chat32 服务器（端口 8080，密码默认 `chat32`）
2. 启动 cloudflared 内网穿透，抓取公网地址 `https://xxxx.trycloudflare.com` 显示在界面
3. 提供"复制公网地址"按钮，发给朋友填进客户端 App 的服务器地址即可连接
4. 前台通知常驻 + 唤醒锁保活 + 开机自启（BOOT_COMPLETED）

## 交付物

- `Chat32-Server-debug.apk`：**81MB，arm64-v8a（64 位），Android 5.0（API 21）及以上**，已签名可直接安装
- 源码：`java/`（MainActivity / ServerService / BootReceiver）、`cpp/native-lib.cpp`（JNI 粘合层）、`assets/`（main.js、server.js、cloudflared）

## 包内结构

```
assets/main.js        # Node 入口：设 CHAT_PASSWORD=chat32、PORT=8080，require('./server.js')
assets/server.js      # Chat32 服务器（与网页版完全一致，历史记录写本机私有目录）
assets/cloudflared    # arm64 静态二进制（Go），tunnel --url http://127.0.0.1:8080
lib/arm64-v8a/libnode.so         # Node.js v18 运行时（nodejs-mobile）
lib/arm64-v8a/libc++_shared.so   # libnode 依赖的 C++ 运行时
lib/arm64-v8a/libnative-lib.so   # JNI 粘合层：String[] -> argv -> node::Start
```

## 界面与操作

- 主界面：状态卡片（运行/停止）、公网地址（等约 10~30 秒出现）、复制按钮、启动/停止按钮
- 停止服务器 = 退出 App（内嵌 Node 无法单独停，只能随进程退出）
- "关闭电池优化"按钮：引导到系统电池优化设置（防杀后台）
- 部分国产系统需在"自启动管理"里手动允许本 App 才能开机自启
- 排障：cloudflared 日志在 App 私有目录 `files/cloudflared.log`；本机访问 `http://127.0.0.1:8080` 可看服务状态

## 客户端怎么连

- 公网：把 App 显示的 `https://xxxx.trycloudflare.com` 发给朋友，填进客户端 App 的"服务器地址"
- 局域网：同一 WiFi 下填 `ws://<服务器手机IP>:8080`（明文 ws 已放行）
- 服务器密码：`chat32`（可改 `assets/main.js` 里的 `CHAT_PASSWORD` 后重新打包）

## 重新构建（本机脚本）

依赖：JDK 8+、Android build-tools 34、android-34 android.jar、NDK r25b（交叉编译 native-lib.so）、
nodejs-mobile v18.20.4 发布包（libnode.so + node 头文件）、cloudflared-linux-arm64。

```bash
# 1) 交叉编译 JNI 粘合层
$NDK/bin/aarch64-linux-android21-clang++ -shared -fPIC -std=c++17 -fno-exceptions -fno-rtti \
  -I<node include 目录> -L<libnode.so 目录> -o libnative-lib.so cpp/native-lib.cpp -lnode

# 2) javac + aapt2 + d8 + zip + zipalign + apksigner（与构建客户端相同的手工链路）
```

## 真机注意事项

- 只支持 **arm64-v8a**（按你的要求"64 位 v8 架构也行"）；32 位旧手机装不上
- 内嵌 Node 运行 server.js 无需 root、无需 Termux
- 若个别设备 DNS 解析异常导致穿透地址迟迟不出现，看 `cloudflared.log` 并重启试试
