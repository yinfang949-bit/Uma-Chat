// Chat32 服务器入口（nodejs-mobile 环境）
// 设置默认密码与端口后加载 server.js
process.env.CHAT_PASSWORD = process.env.CHAT_PASSWORD || 'chat32';
process.env.PORT = process.env.PORT || '8080';
require('./server.js');
