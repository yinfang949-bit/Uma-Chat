// Chat32 服务器 App：JNI 粘合层（官方 nodejs-mobile 样例适配）
// 把 Java 的 String[] 转成 libuv 友好的 argv，然后调用 node::Start 启动 Node 运行时
#include <jni.h>
#include <string>
#include <cstdlib>
#include "node.h"

extern "C" jint JNICALL
Java_com_chat32_server_MainActivity_startNodeWithArguments(
    JNIEnv *env,
    jobject /* this */,
    jobjectArray arguments) {

  jsize argument_count = env->GetArrayLength(arguments);

  // 计算所有参数需要的连续内存大小
  int c_arguments_size = 0;
  for (int i = 0; i < argument_count; i++) {
    c_arguments_size += strlen(env->GetStringUTFChars((jstring)env->GetObjectArrayElement(arguments, i), 0));
    c_arguments_size++; // for '\0'
  }

  char* args_buffer = (char*) calloc(c_arguments_size, sizeof(char));
  char* argv[argument_count];
  char* current_args_position = args_buffer;

  for (int i = 0; i < argument_count; i++) {
    const char* current_argument = env->GetStringUTFChars((jstring)env->GetObjectArrayElement(arguments, i), 0);
    strncpy(current_args_position, current_argument, strlen(current_argument));
    argv[i] = current_args_position;
    current_args_position += strlen(current_args_position) + 1;
    env->ReleaseStringUTFChars((jstring)env->GetObjectArrayElement(arguments, i), current_argument);
  }

  int node_result = node::Start(argument_count, argv);
  free(args_buffer);
  return jint(node_result);
}
